<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ScaleController extends Controller
{
    public function holland(){
        return view('scale.holland');
    }
}
