<?php
if(isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
} else {
    $user_id = auth()->id();
}
?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('لوحة الطالب')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                   
<div class="container my-4">
    <div class="row justify-content-center">
      <!-- Card 1 -->
      <div class="col-md-4">
        <div class="card text-center">
          <div class="card-body">
            <h5 class="card-title">اختبار Holland</h5>
            <p class="card-text">اكتشف المزيد حول اختبار هولاند لمعرفة ميولك المهنية.</p>
            <a href="<?php echo e(url('/disc-test')); ?>" class="btn btn-primary">ابدأ الاختبار</a>
          </div>
        </div>
      </div>
  
      <!-- Card 2 -->
      <div class="col-md-4">
        <div class="card text-center">
          <div class="card-body">
            <h5 class="card-title">اختبار DISC</h5>
            <p class="card-text">تعرف على نمط شخصيتك باستخدام اختبار DISC الشهير.</p>
            <a href="<?php echo e(url('scale/holland')); ?>" class="btn btn-primary">ابدأ الاختبار</a>
          </div>
        </div>
      </div>
  
      <!-- Card 3 -->
      <div class="col-md-4">
        <div class="card text-center">
          <div class="card-body">
            <h5 class="card-title">اختبار الذكاءات</h5>
            <p class="card-text">اكتشف أنواع الذكاءات التي تميزك من خلال هذا الاختبار.</p>
            <a href="<?php echo e(url('/thakaat-test')); ?>" class="btn btn-primary">ابدأ الاختبار</a>
          </div>
        </div>
      </div>
    </div>
  </div>






<?php
$tests = \App\Models\ThakaatResults::where('user_id',   $user_id )->get();

?>
<div class="container my-4">
    <h2 class="text-center mb-4">نتيجة اختبار الذكاءات</h2>
    <ul class="list-group">
      <?php $__currentLoopData = $tests->groupBy('test_number'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testNumber => $testGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item mb-3">
          <div class="d-flex justify-content-between align-items-center">
            <h5>رقم الاختبار: <?php echo e($testNumber); ?></h5>
            
          </div>
  
          <ul class="list-group mt-3">
            <?php $__currentLoopData = $testGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item">
                <div class="d-flex justify-content-between" st>
                  <span>الفئة: <?php echo e($test->category); ?></span>
                  <span>الدرجة: <?php echo e($test->score); ?></span>
                  <span>النسبة: <?php echo e($test->percentage); ?>%</span>
                </div>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>



  <!--holland score-->
  <h2 class="text-center mb-4">نتيجة اختبار holland</h2>

                  <?php
                $holland_scores = \App\Models\HollandPersona::where('user_id',   $user_id )->orderBy('id', 'desc')->first(); 
                         $holland_score=$holland_scores;     
                  ?>
                  
<div class="container my-4">
    <div class="row justify-content-center">
        <!-- Card 1 -->
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-header">
                    رقم 1
                </div>
                <div class="card-body">
                    <?php echo e($holland_score->first_type); ?>

                </div>
            </div>
        </div>
        <!-- Card 2 -->
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-header">
                    رقم 2
                </div>
                <div class="card-body">
                    <?php echo e($holland_score->second_type); ?>

                </div>
            </div>
        </div>
        <!-- Card 3 -->
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-header">
                    رقم 3
                </div>
                <div class="card-body">
                    <?php echo e($holland_score->third_type); ?>

                </div>
            </div>
        </div>
    </div>
  </div>




<!--disc results-->
<h2 class="text-center mb-4">نتيجة اختبار holland</h2>

<div class="row">
<?php
$disc_results = \App\Models\DiscResult::where('user_id',   $user_id )->get();

// $disc_results = $disc_results->results;
?>
<?php $__currentLoopData = $disc_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disc_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = json_decode($disc_result->results); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-header">
                    رقم : <?php echo e($index + 1); ?>

                </div>
                <div class="card-body">
                    <?php echo e($result); ?>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scales\scale-laravel\resources\views/home.blade.php ENDPATH**/ ?>